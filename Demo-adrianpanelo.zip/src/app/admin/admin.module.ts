import { NgModule }       from '@angular/core';
import { CommonModule }   from '@angular/common';

import { AdminRoutingModule, routedAdminComponents }       from './admin-routing.module';

@NgModule({
  imports: [
    CommonModule,
    AdminRoutingModule
  ],
  declarations: [
    [routedAdminComponents]
  ]
})
export class AdminModule {}


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/