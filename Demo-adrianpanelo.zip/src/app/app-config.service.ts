import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { IAppConfiguration } from './app-config.model'
import { environment } from 'src/environments/environment';
 
@Injectable()
export class AppConfiguration {
 
    static settings: IAppConfiguration;
    static isMobileDevice: boolean = false;
    static isTabletDevice: boolean = false;
    static isDesktopDevice: boolean = false;
    
    constructor(private http: HttpClient) {}
 
    load() {
 
        const jsonFile = "assets/appconfig.json";
        
        return new Promise<void>((resolve, reject) => {
            this.http.get(jsonFile).toPromise().then((response : IAppConfiguration) => {
                AppConfiguration.settings = <IAppConfiguration>response;
                if(environment.production) {
                    AppConfiguration.settings.httpDelay=0;
                }
               console.log("Config loaded.");
               //console.log(AppConfiguration.settings);
               resolve();
               
            }).catch((response: any) => {
               reject("Could not load the config file.");
            });
        });
    }
}

