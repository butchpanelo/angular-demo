import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AngularStartComponent } from './start/angular-start.component';

import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
// import { LogoutComponent } from './logout/logout.component';
import { NgSidebarDemoComponent } from './references/ngsidebardemo/ngsidebardemo.component';

import { AuthGuard } from './auth/auth.guard';
import { SelectivePreloadingStrategyService } from './selective-preloading-strategy.service';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full'},
  { path: 'home', component: HomeComponent , data: {animation: 'home'}},
  
  // { path: 'login', component: LoginComponent, canActivate: [AuthGuard], 
  // data: {animation: 'login'}},
  { path: 'angular-start-page', component: AngularStartComponent, data: {animation: 'angular-start-page'}},
  { path: 'pagenotfound', component: PagenotfoundComponent },
  { path: 'references/ngsidebardemo', component: NgSidebarDemoComponent,
  data: {animation: 'ngsidebardemo'}},
  { path: 'about', component: AboutComponent , data: {animation: 'about'}},
  {
    path: 'samples',
    loadChildren: () => import('./samples/samples.module').then(m => m.SamplesModule)
  },
  {
    path: 'admin',
    loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule),
    canLoad: [AuthGuard]
  },
  {
    path: 'user', 
    loadChildren: () => import('./user/user.module').then(m => m.UserModule)
   // canLoad: [AuthGuard]
  },
  {
    path: 'superheroes', 
    loadChildren: () => import('./references/heroes/heroes.module').then(m => m.HeroesModule)
  },
  {
    path: 'crisis-center',
    loadChildren: () => import('./references/crisis-center/crisis-center.module').then(m => m.CrisisCenterModule),
    data: { preload: true }
  },
  { path: 'login', redirectTo: 'user/login', pathMatch: 'full' },
  { path: '**', redirectTo: 'pagenotfound' },
];



@NgModule({
  imports: [RouterModule.forRoot(routes,
    {
      enableTracing: false, // <-- debugging purposes only
      preloadingStrategy: SelectivePreloadingStrategyService,
    })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routedComponents = [
    AngularStartComponent,
    HomeComponent,
    AboutComponent,
    PagenotfoundComponent,
    NgSidebarDemoComponent
    // LogoutComponent
  ]
