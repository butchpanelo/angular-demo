import { Component, OnInit, Input, ChangeDetectionStrategy } from '@angular/core';
import {
  transition,
  trigger,
  style,
  animate,
} from '@angular/animations';
import { MessageOptions } from '../_services/messaging.service';

@Component({
  selector: 'show-message',
  templateUrl: './show-message.component.html',
  styleUrls: ['./show-message.component.css'],
  animations: [
    // trigger(
    //   'myAnimation', [
    //     transition(':enter', [
    //       style({transform: 'translateX(100%)', opacity: 0}),
    //       animate('500ms', style({transform: 'translateX(0)', opacity: 1}))
    //     ]),
    //     transition(':leave', [
    //       style({transform: 'translateX(0)', 'opacity': 1}),
    //       animate('500ms', style({transform: 'translateX(100%)', opacity: 0})),
    //     ])
    //   ]
    // )
    trigger('fadeInOut', [
      transition('void => *', [
        style({opacity:0}), //style only for transition transition (after transiton it removes)
        animate(300, style({opacity:1})) // the new state of the transition(after transiton it removes)
      ]),
      transition('* => void', [
        animate(1000, style({opacity:0})) // the new state of the transition(after transiton it removes)
      ])
    ])
  ]
  //changeDetection: ChangeDetectionStrategy.OnPush,
})

export class ShowMessageComponent implements OnInit {
  @Input('message') messageInfoInput : any;
  @Input('messageType') messageTypeInput: string;
  @Input('duration') durationInput: number = 0;
  @Input('showCloseIcon') showCloseIconInput: boolean = true;

  constructor() {}
  
  private readonly OPTIONS_CLASSNAME = (new MessageOptions()).constructor.name;
  protected _messageInfo: any;
  protected _hasContent: boolean = false;
  protected _showCloseIcon:  boolean;
  public toggleState: boolean = true;

  private readonly defaultMessageType: string = "info";

  ngOnInit(): void {
    // console.log("input-message:", this.messageInfoInput);
    // console.log("input-messageType:", this.messageTypeInput);
    // console.log("input-duration:", this.durationInput);
    // console.log("input-showCloseIcon:", this.showCloseIconInput);

    this._messageInfo = this.parseMessage();
    
    if(this.messageInfoInput.constructor.name==this.OPTIONS_CLASSNAME) {
      this._showCloseIcon = this._messageInfo.showCloseIcon;
    }
    else {
      this._showCloseIcon = (this.showCloseIconInput === true);
    }

    this._hasContent = this._messageInfo.messageText.length>0;
    this._messageInfo.hasHeader = this._messageInfo.messageHeader.length>0
    
    // console.log("msgInfo: ", this._messageInfo);
    var _duration = this._messageInfo.duration;
    _duration = typeof this._messageInfo.duration === "number" ?
        this._messageInfo.duration: this.durationInput; 
    
    if(_duration>0) {
      this.displayMessageUntil(_duration);
    }
  }

  ngAfterViewInit(): void {
    if(typeof this._messageInfo.callback==="function") {
      this._messageInfo.callback(this._hasContent);
    }
  }

  ngOnDestroy() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }
  
  closeMessage() {
    this.toggleState=!this.toggleState;
  }

  private timer: any;
  private displayMessageUntil(duration: number) {
    this.timer = setInterval(() => {
        if(this.toggleState) {
            this.closeMessage();
        }
    }, duration)
  }

  private parseMessage() {
    let msgInfo: any = {};
    msgInfo.alert = {};
    msgInfo.messageHeader ="";
    var inputMessage = this.messageInfoInput;
    
    if(typeof inputMessage === "object") {
        var key = inputMessage.key;
        if(key && inputMessage.value) {
          msgInfo.messageText = inputMessage.value;
          if(key.startsWith("message-")) {
            var split = key.split("-");
            if(split.length===2) {
              msgInfo.messageType=split[1]; 
            }
          }
          else {
            msgInfo.messageType = this.defaultMessageType;
          }
          if(typeof inputMessage.value === "object" && 
          inputMessage.value.constructor.name===this.OPTIONS_CLASSNAME) {
               Object.assign(msgInfo, inputMessage.value);
          }
        }
        else if (inputMessage.constructor.name==this.OPTIONS_CLASSNAME) {
          Object.assign(msgInfo, inputMessage);
        }
        this.setAlertType(msgInfo);
    }
    else {
      msgInfo.messageText = inputMessage.toString();
    }

    if(typeof msgInfo.messageType==="undefined") {
        msgInfo.messageType = this.messageTypeInput
        this.setAlertType(msgInfo); 
    }
    msgInfo.messageText = msgInfo.messageText.replace(/\n/g, "<br />");
    return msgInfo;
  }

  private setAlertType(msgInfo: any) {
    var mtype = msgInfo.messageType.toLowerCase();
    switch(mtype) {
      case "info":
        msgInfo.alert.info = true;
        break;
      case "warning":
        msgInfo.alert.warning = true;
        break;
      case "danger": case "error":
        msgInfo.alert.danger = true;
        msgInfo.alert.error = true;
        break;
      case "success":
        msgInfo.alert.success = true;
        break;
      case "primary":
        msgInfo.alert.primary = true;
        break;
      case "secondary":
        msgInfo.alert.secondary = true;
      case "light":
          msgInfo.alert.light = true;
      case "dark":
        msgInfo.alert.dark = true;
        break;
      default:
        msgInfo.alert.info = true;
    }
  }
}


