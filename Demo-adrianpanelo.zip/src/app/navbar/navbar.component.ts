import { Component, OnInit, ElementRef, ViewChild, NgZone } from '@angular/core';
import { Router, ActivatedRoute }  from '@angular/router';
import { AppConfiguration } from '../app-config.service';
import { AuthService } from '../auth/auth.service';
import { MessagingService } from '../_services/messaging.service';
import { ActionService } from '../_services/action.service';
import { NavbarResizeService } from './navbar-resize.service';

@Component({
  selector: 'nav-bar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  protected homeUrl = AppConfiguration.settings.routes.home;
  protected loginUrl = AppConfiguration.settings.routes.login;
  
  constructor(private _router: Router,
    private _route: ActivatedRoute,
    private _elRef: ElementRef, 
    private _authService: AuthService,
    private _msgService: MessagingService,
    private _actionService: ActionService,
    private _zone: NgZone,
    private _navbarResize: NavbarResizeService
  ) { } 

  @ViewChild("navbar") navbar: ElementRef;
  @ViewChild("navbarContent", { static: false }) navbarContent: ElementRef;

  public collapsed: boolean =true;

  ngOnInit(): void {
    
    
  }

  ngAfterViewInit(): void {
    this._zone.runOutsideAngular(()=> {
      let dim = { height: this.navbar.nativeElement.offsetHeight,
                  width: this.navbar.nativeElement.offsetWidth}
      this._navbarResize.newSize(dim);
      setInterval(()=> {
        let newDim = { height: this.navbar.nativeElement.offsetHeight, 
            width: this.navbar.nativeElement.offsetWidth }

        if(newDim.height !== dim.height && 
          !this.navbar.nativeElement.classList.contains("nav-items-visible")) {
          this._navbarResize.newSize(newDim);
          dim = newDim;
        }

      },500);
    });
  }

  navbarTogglerClick(): void {
    //let navContent = this._el.nativeElement.querySelector("#navbarContent");

    //if (clear || $nav.hasClass("responsive")) {
    if(!this.navbarContent.nativeElement.classList.contains("collapse")) {
       this.collapsed=true;
    }
    else {
       this.collapsed=false;
    }
}

  refreshPage(): void {
       window.location.href="/";
  }

  navlinkClick(event) {
    if(!this.collapsed) { 
      this.navbarTogglerClick();
    }
  }

  navigateTo(relativePath : string): void {
    if(!this.collapsed) { 
      this.navbarTogglerClick();
    }
    this._router.navigate([relativePath]); 
  }

  get isLoggedIn(): boolean {
    return this._authService.credentials?.isAuthenticated || false;
  }

  get currentUsername(): string {
    return this._authService.credentials?.username;
  }
  
  // logout(): void {
  //   this._msgService.closeMessage();
   
  //   if(!this.collapsed) { 
  //     this.navbarTogglerClick();
  //   }
  //   this._router.navigate([this.homeUrl]) 
  // }

  loginClick(): void {
    if(!this.collapsed) { 
      this.navbarTogglerClick();
    }
    if(this.loginUrl === this._router.url) {
      return;
    }
    this._actionService.push("OPEN_LOGIN_SIDEBAR");
  }
}
