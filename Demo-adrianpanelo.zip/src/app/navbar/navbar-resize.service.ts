import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class NavbarResizeService {

//Observable source
  private _resizeSubject = new BehaviorSubject<{height:number,width:number}>(null);
  //Obeservable item
  public resize$ = this._resizeSubject.asObservable();
  //Service command
  public newSize(size: {height: number, width: number}) {
      this._resizeSubject.next(size);
  }
}