import { trigger, state, animate, transition, style } from '@angular/animations';
import { reduce } from 'rxjs/operators';

export const fadeInAnimation =
    trigger('fadeInAnimation', [
        // route 'enter' transition
        transition(':enter', [

            // styles at start of transition
            style({ opacity: 0,  height: 0 }),

            // animation and styles at end of transition
            animate('5s', style({ opacity: 1, height: "*" }))
        ]),
    ]);