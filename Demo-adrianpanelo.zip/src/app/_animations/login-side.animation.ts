import { trigger, state, animate, transition, style } from '@angular/animations';

export const leftSideAnimation =
    trigger('slideInOut', [

        state('*', style({
            // the view covers the whole screen with a semi tranparent background
            position: 'fixed',
            top: 0,
            left: 0,
            height: "100%",
            right: "100%",
            bottom: 0,
            //backgroundColor: 'rgba(0, 0, 0, 0.8)'
            backgroundColor: "red"
        })),   
    state('in', style({
      transform: 'translate3d(0, 0, 0)'
    })),
    state('out', style({
      transform: 'translate3d(-400%, 0, 0)',
      
    })),/* state('*', style({
        // the view covers the whole screen with a semi tranparent background
        position: 'relative',
        top: 0,
        left: 0,
        right: "100%",
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.8)'
    })), */
    transition('in => out', animate('500ms ease-in-out',  style({
        // transition the right position to -400% which slides the content out of view
        left: '-400%',
        
        // transition the background opacity to 0 to fade it out
       // backgroundColor: 'rgba(0, 0, 0, 0)'
    }) )),
     transition('out => in', animate('800ms ease-in-out', style({
    //     // transition the right position to -400% which slides the content out of view
         //left: "100%"
          //     // transition the background opacity to 0 to fade it out
         //backgroundColor: 'rgba(0, 0, 0, 0.8)'
     })))
    
  //  ))
  ]);