import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { NavigationStart } from '@angular/router';
 
@Injectable({providedIn: 'root'})
export class NavStartService {
  constructor() {}
   
  //Observable source
  private _subject = new BehaviorSubject<string>(null);
  //Obeservable item
  public get url$() {
    return this._subject.asObservable();
  } 
  //Service command
  public push(event: NavigationStart) {
    //this._storageService.store("message",this.options);
    this._subject.next(event.url);
  }
 
}

