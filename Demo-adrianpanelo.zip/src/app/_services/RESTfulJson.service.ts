import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders, HttpErrorResponse  } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError, delay } from 'rxjs/operators';

import { AppConfiguration } from '../app-config.service';
import { JsonUtil } from '../_utils/jsonutil.service'

@Injectable({providedIn: 'root'})
export class RESTfulJsonService {
    constructor(private _http: HttpClient, 
      private jsonUtil: JsonUtil) {}

    protected HTTP_DELAY = AppConfiguration.settings.httpDelay;

    private isNonEmptyString(text: any) {
      if(typeof text === "string") {
        return (text.trim().length>0);
      }
      return false;
    }

    private transformOptions(httpMethod: HttpMethod, options?: any) : any {
      var tOption = {};
      
      let hasParams : boolean = (typeof options==="object" && options.params) ? true : false;
      let hasHeaders : boolean = (typeof options==="object" && options.headers) ? true : false;
      let withCredentials : boolean = (typeof options==="object" && options.withCredentials===true) ? true : false;
      let showFullError : boolean = (typeof options==="boolean" || 
           typeof options==="object" && options.showFullError===true);

      let responseType : string = "text";
      let observeType : string = "body";

      if(typeof options==="object") {
          if(this.isNonEmptyString(options.responseType)) {
            responseType = options.repsponseType;
          }
          if(this.isNonEmptyString(options.observe)) {
            observeType = options.observe;
          }
      }

      let params: any;
      if(hasParams) {
        if(options.params instanceof HttpParams) {
          params = options.params;
        }
        else {
          // params = new HttpParams();
          // let keys = Object.keys(options.params) as [];
          // let values = Object.values(options.params) as [];
          // for(let i=0 as number;i<keys.length;i++) {
          //     params = params.append(keys[i],values[i]);
          // }
          if(this.jsonUtil.isJsonAndNotEmpty(options.params)) {
            params = new HttpParams({fromObject : options.params });
          }
        }
      }
      let headers: any;
      if(hasHeaders) {
        if(options.headers instanceof HttpHeaders) {
          headers = options.headers;
        }
        else {
          if(this.jsonUtil.isJsonAndNotEmpty(options.headers)) {
            headers = new HttpHeaders();
            let keys = Object.keys(options.headers);
            let values = Object.values(options.headers);
            for(let i=0;i<keys.length;i++) {
              headers = headers.append(keys[i],values[i]);
            }
          }
        }
      }
      if(httpMethod==="POST" || httpMethod==="PUT" || httpMethod==="PATCH") {
        var key = "content-type";
        if(typeof headers === "undefined") { 
          headers=new HttpHeaders();
        }
        if((<HttpHeaders>headers).has(key)==false) {
         headers = headers.append(key,"application/json");
        }
      
        let hasBody : boolean = (typeof options==="object" && options.body) ? true : false;
        if(hasBody) {
          hasBody = this.jsonUtil.isJsonAndNotEmpty(options.body);
          if(hasBody) {
            Object.assign(tOption,{"requestBody" : this.jsonUtil.toJsonString(options.body)});
          }
        }
      }
      
      Object.assign(tOption, {'hasHeaders' : (typeof headers != "undefined") });
      Object.assign(tOption, {'hasParams' : (typeof params != "undefined")});
      Object.assign(tOption, {'withCredentials' : withCredentials});
      Object.assign(tOption, {'headers': headers});
      Object.assign(tOption, {'params': params});
      Object.assign(tOption, {'responseType': responseType});
      Object.assign(tOption, {'observe': observeType});
      Object.assign(tOption, {'showFullError' : showFullError});
      console.log(tOption);
      return tOption;
    }
   
    handleError(err: any, showFullError: boolean) : Observable<any> {
        let errorMessage = 'Unknown error!';
        if (err.error instanceof ErrorEvent) {
          // A client-side or network error occurred. Handle it accordingly.
          errorMessage = `Error: ${err.error.message}`;
        } 
        else if (err instanceof HttpErrorResponse){
          // The backend returned an unsuccessful response code.
          // The response body may contain clues as to what went wrong,
          errorMessage = `Http Request Error Code: ${err.status}\nMessage: ${err.message}`;
        }
        console.error(errorMessage);
        // return an observable with a user-facing error message
        if(!showFullError) {
            errorMessage = 'Something bad happened; please try again later.';
        }
        return throwError(errorMessage);
      }

    public httpGet(url: string, options?: any) {
      let tOptions : any = this.transformOptions("GET", options);
      let args = this.setHttpOptions(tOptions);
      return this._http.get(url,args)
        .pipe(
          delay(this.HTTP_DELAY),
          map((data) => {
            if(typeof data === "string") {
              data = JSON.parse(data);
            }
            return data;
          }), 
          catchError((err)=> { 
            return this.handleError(err, tOptions.showFullError)
      }));
    }

    public httpPost(url: string, options?: any) {
      let tOptions = this.transformOptions("POST", options); 
      let body: string = tOptions.requestBody ? tOptions.requestBody : "";
      let args = this.setHttpOptions(tOptions);
      return this._http.post(url,body,args)
        .pipe( 
          delay(this.HTTP_DELAY),
          map((data) => {
            if(typeof data === "string") {
              data = JSON.parse(data);
            }
            return data;
          }),    
          catchError((err)=> { 
            return this.handleError(err, tOptions.showFullError)
      }));
    }

    public httpPut(url: string, options?: any) {
      let tOptions = this.transformOptions("PUT", options); 
      let body: string = tOptions.requestBody ? tOptions.requestBody : "";
      let args = this.setHttpOptions(tOptions);
      return this._http.put(url,body,args)
        .pipe( 
          delay(this.HTTP_DELAY),
          map((data) => {
            if(typeof data === "string") {
              data = JSON.parse(data);
            }
            return data;
          }),    
          catchError((err)=> { 
            return this.handleError(err, tOptions.showFullError)
      }));
    }

    public httpPatch(url: string, options?: any) {
      let tOptions = this.transformOptions("PATCH", options); 
      let body: string = tOptions.requestBody ? tOptions.requestBody : "";
      let args = this.setHttpOptions(tOptions);
      return this._http.put(url,body,args)
        .pipe( 
          delay(this.HTTP_DELAY),
          map((data) => {
            if(typeof data === "string") {
              data = JSON.parse(data);
            }
            return data;
          }),    
          catchError((err)=> { 
            return this.handleError(err, tOptions.showFullError)
      }));
    }

    public httpDelete(url: string, options?: any) {
      let tOptions = this.transformOptions("DELETE", options); 
      let args = this.setHttpOptions(tOptions);
      return this._http.delete(url,args)
        .pipe( 
          delay(this.HTTP_DELAY),
          map((data) => {
            if(typeof data === "string") {
              data = JSON.parse(data);
            }
            return data;
          }),    
          catchError((err)=> { 
            return this.handleError(err, tOptions.showFullError)
      }));
    }

    private setHttpOptions(options: any): any {
      var args = {};
      if(options.hasParams) { Object.assign(args, { 'params': options.params } ) };
      if(options.hasHeaders) { Object.assign(args, { 'headers' : options.headers } ) };
      if(options.withCredentials) { Object.assign(args, { 'withCredentials' : options.withCredentials } ) };
      Object.assign(args, { 'observe' : options.observe });
      Object.assign(args, { 'responseType' : options.responseType });
      return args;
    }
}

type HttpMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
