import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
 
@Injectable({providedIn: 'root'})
export class ActionService {
  constructor() {}
   
  //Observable source
  private _subject = new BehaviorSubject<ACTION_TYPE>(null);
  //Obeservable item
  public get actionType$() {
    return this._subject.asObservable();
  }

  //public actionType$ = this._subject.asObservable();

  //Service command
  public push(action: ACTION_TYPE) {
    //this._storageService.store("message",this.options);
    this._subject.next(action);
  }
 
}

export type ACTION_TYPE = "LOGIN-CLICK" | "LOGOUT" | "LOGGED-IN" | "OPEN_LOGIN_SIDEBAR";
