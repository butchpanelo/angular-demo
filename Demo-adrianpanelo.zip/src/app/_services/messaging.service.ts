import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

//type ShowMessageDirective = "close"

@Injectable({providedIn: 'root'})
export class MessagingService {
  private options: MessageOptions;
  
  constructor() { 
    this.init();
  }

  //Observable source
  private _subject = new BehaviorSubject<MessageOptions | string>(null);
  //Obeservable item
  
  //public newMessage$ = this._subject.asObservable();
  get newMessage$(): Observable<any> {
    return this._subject.asObservable();
  } 

  //Service command
  public showMessage() {
    this._subject.next(this.options);
  }
  
  public closeMessage() {
    this._subject.next("close");
  }

  private init(): void {
    this.options = new MessageOptions();
  }

  public setMessage(message: string): MessagingService {
    this.init();
    this.options.messageText = message;
    return this;
  }

  public setMessageType(messageType: MESSAGE_TYPE): MessagingService {
    this.options.messageType = messageType;
    return this;
  }

  public setDuration(duration: number): MessagingService {
    this.options.duration = duration;
    return this;
  }

  public setMessageHeader(messageHeader: string): MessagingService {
    this.options.messageHeader = messageHeader;
    return this;
  }

  public setShowCloseIcon(showCloseIcon: boolean): MessagingService {
    this.options.showCloseIcon = showCloseIcon;
    return this;
  }

  public setCallback(callback: any): MessagingService {
    this.options.callback = callback;
    return this;
  }
}

export class MessageOptions {
  messageText: string;
  messageHeader: string
  messageType: MESSAGE_TYPE = "info"
  duration: number = 0;
  showCloseIcon: boolean = true;
  callback: any
}

export type MESSAGE_TYPE = "info" | "success" | "error" | "warning" | "danger" | "primary" | "secondary" | "light" | "dark";
