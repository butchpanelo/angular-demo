import { TestBed } from '@angular/core/testing';

import { NativeDialogService } from './native-dialog.service';

describe('NativeDialogService', () => {
  let service: NativeDialogService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NativeDialogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
