
import { slideInAnimation } from './_animations/route-animation';
import { Component, ViewChild, ElementRef, ChangeDetectionStrategy, Directive,
  AfterViewInit, 
  ViewChildren, QueryList, KeyValueDiffer, KeyValueDiffers, NgZone, HostBinding} from '@angular/core';
import { LocalStorageService } from './_services/localstorage.service';
import { NavStartService } from './_services/navstart.service';
import { NavbarResizeService } from './navbar/navbar-resize.service';
import { ActionService } from './_services/action.service';
import { ACTION_TYPE } from './_services/action.service';
import { Router, Event, NavigationStart, NavigationEnd, NavigationError } from '@angular/router';
import { Sidebar, SidebarContainer, CloseSidebar, SidebarModule  } from 'ng-sidebar'
import { Subscription } from 'rxjs';
import { FORM_STATUS } from './_global/forms/form-status.type';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  // animations: [slideInOutAnimation],
  // host: { "[@slideInOutAnimation]": ''
  animations: [slideInAnimation]
 // changeDetection: ChangeDetectionStrategy.OnPush,
 
})
export class AppComponent {
 // @HostBinding('@.disabled')
 // public animationsDisabled = true;

  constructor(private _router: Router,
    // private _storageService: LocalStorageService,
    // private differs: KeyValueDiffers,
    // private zone: NgZone,
    private _navstartService: NavStartService,
    private _actionService: ActionService,
    private _navbar: NavbarResizeService) { 

    _router.events.subscribe( (event: Event) => {
      
        if (event instanceof NavigationStart) {
            _navstartService.push(event);
        }

        if (event instanceof NavigationEnd) {
            // Hide loading indicator
            this.loading = false;
      //      console.log(event);
        }

        if (event instanceof NavigationError) {
            // Hide loading indicator
            this.loading = false;
            // Present error to user
        //    console.log(event.error);
        }
    });

      
    this.show_backdrop=true;
    

  }

public loading = true;
private differ: any;
  private objDiffer: Array<KeyValueDiffer<string,any>>;
 
  public show_backdrop : boolean = true;
  public login_sidebar_opened: boolean = false;
  private canremoveBackdrop=true;
  //public loginsidebar_showbackdrop: boolean = true;
  private openCount: number = 0;

  @ViewChild("wrapper") wrapper: ElementRef
  @ViewChild("sidebar_container", { static: false }) sidebar_container: SidebarContainer
  @ViewChild("sidebar_login", { static: false }) sidebar_login: Sidebar;
  @ViewChild("sidebar_login", { static: false }) sidebar_login_el: ElementRef;
 
  @ViewChildren(Sidebar) sidebars!: QueryList<Sidebar>; 

  
  private getOpenCount() {
   // setTimeout(()=> {
      this.openCount = this.sidebars.filter((s)=> s.opened===true).length;
      

    //},1);
  //  console.log("Opened Sidebar count: ", this.openCount);
  }

  private subLogin: Subscription;
  private subNavbar: Subscription;

  ngOnInit(): void {
    // console.log('MyComponent - ngOnInit');
    // this.objDiffer = new Array<Sidebar>();
    // this.sidebars.forEach((s,index) => {
    //    this.objDiffer[index] = this.differs.find(s).create();

    // });

    this.subLogin = this._actionService.actionType$.subscribe((action) => {
        if(action) {
          if(action==="OPEN_LOGIN_SIDEBAR") {
            //var prev = this.login_sidebar_opened;
  
            //this.message_sidebar_opened=false;
            //this.login_sidebar_opened= true;
                     
            this.sidebar_login.open();
  
            //this._storageService.remove("loginclicked");
            //if(prev) {
            //  this.canremoveBackdrop=false;
            //}
            //if(prev) {
            //  console.log("Adding backdrop");
            //  this.onOpenStart(this.sidebar_login);
            //}
          }    
          // else if(action==="LOGGED-IN") {
          //   //this.login_sidebar_opened=false;
          //   this.sidebar_login.close();
          //   //console.log('sidebar_login',this.sidebar_login);
          // }

        }
    });

    this.subNavbar = this._navbar.resize$.subscribe((newsize) => {
      if(newsize) {
        this.wrapper.nativeElement.style.top=newsize.height+"px";
      }
    });

    // this._storageService.changes.subscribe(data => {
        
    //   if(data) {
    //     console.log(data);
    //     if(data.key==="loginclicked") {
    //       var prev = this.login_sidebar_opened;

    //       //this.message_sidebar_opened=false;
    //       //this.login_sidebar_opened= true;
    //       if(this.openCount>1) {
            
    //         this.sidebar_message.close();
    //       }
          
    //       this.sidebar_login.open();

    //       this._storageService.remove("loginclicked");
    //       if(prev) {
    //         this.canremoveBackdrop=false;
    //       }
    //       //if(prev) {
    //       //  console.log("Adding backdrop");
    //       //  this.onOpenStart(this.sidebar_login);
    //       //}
    //     }    
    //     else if(data.key==="username") {
    //       //this.login_sidebar_opened=false;
    //       this.sidebar_login.close();
    //       console.log('sidebar_login',this.sidebar_login);
    //     }
    //     // else if(data.key.startsWith("message")) {
          
    //     //   var key: string = data.key;
    //     //   this._storageService.remove(key);
    //     //   this.setMessage(data);
    //     //   this.sidebar_message.open();
    //     //   //this.message_sidebar_opened=true;
          
    //     //   // //this.sidebar_container.showBackdrop=false;
          
    //     //   //this.hasBackdrop = false; 
    //     //   //this.message_sidebar.showBackdrop;
    //     // }
    //   }
      
  // });
    
    
  }

  ngOnDestroy(): void {
    if(this.subLogin) {
      this.subLogin.unsubscribe();
    }
    if(this.subNavbar) {
      this.subNavbar.unsubscribe();
    }
  }

 
   // Object.assign(sidebar_login, { 'showbackdrop' :  true });
   ngDoCheck() {
      // this.sidebars.forEach((sb, index) => {
      //     const objDiff = this.objDiffer[index];
      //     const objChanges = objDiff(sb);
      //     if(objChanges) {

      //       objChanges.forEachChangedItem((changedItem) => {
      //         console.log(changedItem.key);
      //       }
      //       )
      //     }

      // });  
     
      //console.log(this.sidebars);
      //this.openCount = this.sidebars.filter((s)=> s.opened===true).length;
      

      //},1);
      // if(this.sidebars) {
      //   this.openCount = this.sidebars.filter((s)=> s.opened===true).length;
      // }
      // console.log("Opened Sidebar count: ", this.openCount);

   }

   ngAfterViewInit() {
    this.show_backdrop=true;
  //  this.sidebar_container.showBackdrop=this.show_backdrop;
  //  this.sidebar_login.showBackdrop=this.show_backdrop;

   


    //this.sidebar_login.open();
    // this.getOpenCount();
    // this.sidebars.changes.subscribe((r) => {
    //  this.getOpenCount();
    // this.zone.runOutsideAngular(() => {
    //     setInterval(()=> {
    //       this.getOpenCount();
    //     },1);

    // console.log(this.sidebar_message_element.nativeElement.offsetHeight);
    // console.log(this.sidebar_message_element.nativeElement.querySelector("aside").offsetHeight);

    //}
    //);

  
   
    // console.log("Hello ", this.sidebarcontent.nativeElement.parentElement);
    //var sidebarcontent = this.sidebarcontent.nativeElement.parentElement;
    //sidebarcontent.style.display="contents";
   // sidebarcontent.classList.remove('ng-sidebar__content');
    //sidebarcontent.classList.add('ng-sidebar__content-fix');

    
  
    //console.log(this.getMatchedCSSRules(sidebarcontent));
  }

  public onFormStatus(status: FORM_STATUS) {
    if(status==="success" || status==="cancel") {
      this.sidebar_login.close();
    }
  }

  public hasBackdrop: boolean = false;
  public backdropHeight: string = "100%";

  private removeBackdrop(element, forceremove?) {
    
    if((element.showBackdrop=="true" || forceremove) 
      && (typeof this.wrapper != "undefined")) { 
      if(this.canremoveBackdrop) {
        console.log("Removing backdrop");
        // var el = this.wrapper.nativeElement;
        // this.hasBackdrop=false;
        // this.backdropHeight = "100%";
        // el.classList.remove("backdrop");
        
        // el.style.height = "100%";

        //el.style.width = "100%";
        // var ngBackdrop = this.wrapper.nativeElement.querySelector(".ng-sidebar__backdrop");
        // if(ngBackdrop !=null && typeof ngBackdrop != "undefined") {
        //   console.log("ngBackdrop",typeof ngBackdrop);
        //   ngBackdrop.remove();
        // }

      //  console.log("removeBackdrop",el.classList.contains("backdrop")==false);
      }
      else {
        this.canremoveBackdrop=true;
      }
    } 
  }

   public onOpenStart(element): void {
    console.info('Sidebar OpenStart');
    console.log(element);
    //element.showBackdrop = true;
    console.log("typeof element.showBackdrop: ",typeof element.showBackdrop);
    if(element.showBackdrop=="true") {
      console.log("OpenStart 1", element.showBackdrop);
      var y = document.body.clientHeight > window.innerHeight ? 
                    document.body.clientHeight : window.innerHeight
        //    x = document.body.clientWidth > window.innerWidth ? 
        //            document.body.clientWidth: window.innerWidth,
        var el = this.wrapper.nativeElement;
     //   el.classList.add("backdrop");
        this.hasBackdrop=true;
       // el.style.height = y + "px";
        //el.style.width = x + "px";
    } 
    else {
      console.log("OpenStart 2", element.showBackdrop);
      //this.sidebar_container.showBackdrop=false;
      //  this.removeBackdrop(element,true);
      //console.log(this.sidebar_message_element.nativeElement.offsetHeight);
      //console.log(this.sidebar_message_element.nativeElement.querySelector("aside").offsetHeight);
    }
    //console.log("typeof element.showBackdrop: ",typeof element.showBackdrop);
    //this.show_backdrop=element.showBackdrop;
    console.log('container showBackdrop: ',this.sidebar_container.showBackdrop);
    console.log('container: ', this.sidebar_container);
} 
    
  public onCloseStart(element): void {
    console.info('Sidebar CloseStart');
    console.log(element);
    
    if(element.showBackdrop) {
      //this.sidebar_container.showBackdrop=false;
   //   this.show_backdrop=false;
      //setInterval(()=> {
      //this.sidebar_container.
      //},1000)
      //element.showBackdrop="false";
      this.sidebar_container.showBackdrop=false;
      var ngBackdrop = this.wrapper.nativeElement.querySelector(".ng-sidebar__backdrop");
            if(ngBackdrop !=null && typeof ngBackdrop != "undefined") {
              console.log("ngBackdrop",typeof ngBackdrop);
              ngBackdrop.remove();
            }
    }
    //console.log('container showBackdrop: ',this.sidebar_container.showBackdrop);
    console.log('container: ', this.sidebar_container);
    //console.log('showBackdrop',element.showBackdrop);
   // this.removeBackdrop(element);
  }

  public onClose(element): void {
    //(<Sidebar>element).triggerRerender();
    console.info('Sidebar Close');
    //console.log('container showBackdrop: ',this.sidebar_container.showBackdrop);
    console.log('container: ', this.sidebar_container);
    if(element.showBackdrop) {
     
        



    }
  }

}
