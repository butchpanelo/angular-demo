export interface IAppConfiguration {
 
    routes: {
        login:string,
        home:string

    },
    localdbserver: {
        baseURL:string,
        path: {
            users:string,
            products:string,
            heroes:string
        }
    },

    links: {
        productRepository:string,
        githubRepository:string
    },

    httpDelay: number,
    pattern: {
        email: { regexpr:string, criteria:string },
        password: { regexpr:string, criteria:string }
    },

    device_window_size_cuttoff: {
        
    }
}