import { Component, ViewChild } from '@angular/core';
import { Router, Event, NavigationStart } from '@angular/router';
import { Sidebar } from 'ng-sidebar'
import { Subscription } from 'rxjs';

import { MessagingService } from '../../_services/messaging.service';

@Component({
  selector: 'message-sidebar',
  templateUrl: './message-sidebar.component.html',
  styleUrls: ['./message-sidebar.component.css']
  //changeDetection: ChangeDetectionStrategy.OnPush,
})

export class MessageSidebarComponent  {
  constructor(private _router: Router,
    private _messageService: MessagingService) {
      _router.events.subscribe((event: Event) => {
        if (event instanceof NavigationStart) {
           this.sidebar_opened=false;
        }
    });
    this.sidebar_opened = false;    
  }
  
  public sidebar_opened: boolean;
  public messageInfo: any;
  public messageType: string;
  private subscription: Subscription;

  @ViewChild("sidebar_message", { static: false }) sidebar_message: Sidebar;
  
  ngOnInit(): void {
    this.subscription = this._messageService.newMessage$.subscribe(data => {
      if(this.sidebar_message===undefined) { 
        return;
      }
      if(data===null || data===undefined) {
        this.sidebar_message.close();
        return;
      }
      if(data==="close") {
        this.sidebar_message.close();
      }
      else if(data.constructor.name==="MessageOptions") {
        if(this.sidebar_message.opened) {
          this.sidebar_opened=!this.sidebar_message.opened;
          setTimeout(() => {
            this.sidebar_opened=!this.sidebar_message.opened;
          }, 0);
        }
        this.setMessage(data);
        if(!this.sidebar_message.opened) {
          this.sidebar_message.open();
        }
      }
    });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  private setMessage(data: any): void {
    this.messageInfo = data;
    this.messageType = "";
  }
}
