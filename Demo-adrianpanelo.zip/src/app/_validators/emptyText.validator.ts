import { FormControl, ValidatorFn } from '@angular/forms';
import { Utility } from '../_global/utility';

export function emptyTextValidator (): ValidatorFn {
    return (control: FormControl): { [key: string]: boolean } | null => { 
      if(Utility.isAllWhiteSpace(control.value)) {
        return {
           empty: true
        }
      }
    //   let regex: RegExp = /^.*[^\s]+.*$/;
    //   if (regex.test(control.value)) {
    //     return null;
    //   }
      return null;
    }
}


