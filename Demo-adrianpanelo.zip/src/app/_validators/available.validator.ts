import { AbstractControl, AsyncValidatorFn, ValidationErrors, FormControl, Form } from '@angular/forms';
import { Observable, of, pipe } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import { UserService } from '../user/_services/user.service';
import { Utility } from '../_global/utility';

export class emailAvailableValidator {

    static createValidator(service: UserService): AsyncValidatorFn {

        return (control: FormControl) : Observable<ValidationErrors> => {

            if(!control.dirty || Utility.isAllWhiteSpace(control.value)) {
                return of(null);
            }
            return service.isEmailExists(control.value).pipe(
                map((result: boolean) => result ? { available: true }: null)

            );

        }
    }
}

export class usernameAvailableValidator {
    static createValidator(service: UserService): AsyncValidatorFn {
        
        return (control: FormControl) : Observable<ValidationErrors> => {
            if(!control.dirty || Utility.isAllWhiteSpace(control.value)) {
                return of(null);
            }
            return service.isUsernameExists(control.value).pipe(
                map((result: boolean) => result ? { available: true }: null)

            );

        }
    }
}


