import { FormGroup, FormBuilder, Validators, AbstractControl, FormControl, ValidatorFn } from '@angular/forms';

export function compareValidator (otherControlName: string, matchEmpty: boolean): ValidatorFn {

 
    return (control: FormControl): { [key: string]: boolean } | null => { 
      //let thisControl: FormControl;
      let otherControl: FormControl;
  
      if (!control.parent) {
        return null;
      }
  
        otherControl = control.parent.get(otherControlName) as FormControl;
        if (otherControl===null || otherControl===undefined) {
          throw new Error(`compareValidator(): ${otherControlName} is not found in parent group.`);
        }

      
      
      if(!matchEmpty) {
      if (otherControl.value===null || control.value===null) {
        return null;
      }

      
      if (otherControl.value==="" || control.value==="") {
        return null;
      }
    

      if (control.value==="") {
        return null;
      }
    }

      if (otherControl.value !== control.value) {
        return {
          compare: true
        };
      }
  
      return null;
    }
}