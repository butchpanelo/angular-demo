import { FormGroup, FormBuilder, Validators, AbstractControl, FormControl, ValidatorFn } from '@angular/forms';
import { Utility } from '../_global/utility';

export function spaceBeforeTextValidator (): ValidatorFn {
    return (control: FormControl): { [key: string]: boolean } | null => { 
      let regex: RegExp = /^[^\s]+.*$/;

      if(Utility.isAllWhiteSpace(control.value)) {
          return null;
      }
      if (regex.test(control.value)) {
        return null;
      }
      return {
        spaceBeforeText: true
      }
    }
}