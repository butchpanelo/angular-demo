import { Injectable } from '@angular/core';

@Injectable({providedIn: 'root' })
export class JsonUtil {
   
    private isObject(obj: any) : boolean {
        return obj!==null && (typeof obj === "object");
    }

    public isJsonFormat(obj: any) : boolean {
        var jObj1: object, jObj2: object, jString1: string, jString2: string
        try {
            if(obj==null || typeof obj === "undefined") {
                return false;
            }
        
            if(typeof obj === "string") {
                obj = obj.trim();
                if(obj.length==0) {
                    return false;
                }
                if(obj.startsWith("{")==false || obj.endsWith("}")==false) {
                    return false;
                }
                jObj1 = JSON.parse(obj);
                jString1 = JSON.stringify(jObj1);
                jObj2 = JSON.parse(jString1);
                jString2 = JSON.stringify(jObj2);
                return (jString1===jString2);
            }
            if(typeof obj === "object") {
                if(obj.constructor != Object) {
                    return false;
                } 
                jString1 = JSON.stringify(obj);
                jObj1 = JSON.parse(jString1);
                jString2 = JSON.stringify(jObj1);
                if(jString1 === jString2) {
                    return true;
                }
            }
        return false;
       }
        catch(err) {
            //console.error(err);
            return false;
        }
    }

    public isJsonAndNotEmpty(obj: any) : boolean {
        var isJson : boolean = this.isJsonFormat(obj);
        if(!isJson) {
            return false;
        }
        var jObj: object = {};
        if(typeof obj === "string") {
            jObj = JSON.parse(obj);
        }
        else {
            Object.assign(jObj,obj);
        }
        return (Object.keys(jObj).length>0);
    }

    public toJsonString(obj: any) : string {
        if(this.isJsonFormat(obj)===false) {
            throw "Object is not in Json format.";
        }
        if(typeof obj === "string") {
            return obj;
        }
        else {
            return JSON.stringify(obj);
        }
    }
}