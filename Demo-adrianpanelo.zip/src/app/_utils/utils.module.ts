
// import { NgModule, ModuleWithProviders } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { UtilityService } from './utils.service';

// @NgModule ({
// imports: [CommonModule],
//     exports: [CommonModule],
//         providers: [UtilityService]
    
// }



// )
// export class UtilityModule {
    
//     static forRoot(): ModuleWithProviders<UtilityModule> {
//     return {
//       ngModule: UtilityModule,
//       providers: [
//         {provide: UtilityService  }
//       ]
//     };
//   } }
