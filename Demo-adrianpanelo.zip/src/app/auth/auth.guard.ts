import { Injectable } from '@angular/core';
import { CanActivate, Router,
    ActivatedRouteSnapshot,
    RouterStateSnapshot,
    CanActivateChild,
    NavigationExtras,
    CanLoad, Route } from '@angular/router';
import { AppConfiguration } from '../app-config.service';
import { AuthService} from './auth.service'
import { MessagingService } from '../_services/messaging.service';
import { NavStartService } from '../_services/navstart.service';

@Injectable({providedIn: 'root'})
export class AuthGuard implements CanActivate, CanActivateChild, CanLoad {
    protected loginUrl = AppConfiguration.settings.routes.login;
    protected homeUrl = AppConfiguration.settings.routes.home;
    protected navstartUrl: string;
  
    constructor(private _router: Router, 
      private _authService: AuthService,
      private _messagingService: MessagingService,
      private _navstartService: NavStartService) { 
        _navstartService.url$.subscribe((url) => {

          this.navstartUrl = url;
        });
      }
    

      
      canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        return this.checkLogin(state.url);
      }
    
      canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        return this.canActivate(route, state);
      }
    
      canLoad(route: Route): boolean {
        let url = `/${route.path}`;
        return this.checkLogin(url);
      }
    
      checkLogin(url: string): boolean {
        //if (this.authService.isLoggedIn) { return true; }
        //console.log('url',url);
        console.log('authenticated',this._authService.credentials?.isAuthenticated);
        if (this._authService.credentials?.isAuthenticated) { 
          if(url==this.loginUrl) {
            this._router.navigate([this.homeUrl]);
            this._messagingService.setMessage("You are already logged in.")
              .setDuration(5000)
              .setMessageType("warning")
              .showMessage();
          }
          return true;   
        }
        else if(url===this.loginUrl) {
          return true;  
        }
  
        // Store the attempted URL for redirecting
        //this._authService.redirectUrl = url;
        this._authService.redirectUrl = this.navstartUrl || url;

        // Create a dummy session id
        let sessionId = 123456789;
    
        // Set our navigation extras object
        // that contains our global query params and fragment
        let navigationExtras: NavigationExtras = {
          queryParams: { 'session_id': sessionId },
          fragment: 'anchor'
        };
    
        // Navigate to the login page with extras
        //this._router.navigate([this.loginUrl], navigationExtras);
        this._router.navigate([this.loginUrl]);
        return false;
      }
}

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/
