import { Injectable } from '@angular/core';

import { Observable, of } from 'rxjs';
import { tap, delay } from 'rxjs/operators';
import { LocalStorageService } from '../_services/localstorage.service';

@Injectable({providedIn: 'root'})
export class AuthService {
  //public isLoggedIn = false;
  //public isLoggedIn : Observable<boolean>;
  
  // store the URL so we can redirect after logging in
  public redirectUrl: string;
  private _credentials: any = {};
  private _notified: boolean;

  constructor(private localStorage: LocalStorageService) {}

  private getCredentials() {
      if(localStorage.getItem("username")!=null) {
        this._credentials.username = localStorage.getItem("username");
        this._credentials.isAuthenticated = true;
       // this.notified = false;
      }
      else {
        this._credentials = {};
      }
      return this._credentials;
  }

  private clearCredentials() {
      localStorage.removeItem("username");
      this._credentials = {};
  }

  get credentials(): any {
      return this.getCredentials();
  }

  get notified(): boolean {
    return this._notified;
  }
  set notified(value: boolean) {
    this._notified = value;
  }

  authenticate(usernameOrEmail: string, password: string): Observable<any> {
    this.notified = false;
    localStorage.setItem("username",usernameOrEmail);
    this.getCredentials();
    return of(this._credentials).pipe(
      delay(1000)      

    );
  }

  protected isLoggedIn: boolean = false;
  login2(): Observable<boolean> {
    return of(true).pipe(
      delay(1000),
      tap(() => 
      this.isLoggedIn = true
    //    localStorage.setItem("username","Butch")
    ));
  }

  logout(): boolean {
    this.isLoggedIn = false;
    this.clearCredentials();
    return true;
  }
}


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/