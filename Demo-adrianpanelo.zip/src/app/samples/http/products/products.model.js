export interface IProduct {
    ProductID: number;
    ProductName: string;
 }
 
 export interface IProductList extends IProduct {
    ProductOrdered: boolean;
}