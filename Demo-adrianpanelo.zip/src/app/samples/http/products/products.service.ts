import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IProductList } from './products.model';
import { RESTfulJsonService} from 'src/app/_services/RESTfulJson.service'
import { AppConfiguration} from 'src/app/app-config.service'


@Injectable()
export class ProductService {
   constructor(private restService: RESTfulJsonService) {}
   
   //protected _producturl = AppConfiguration.settings.links.productRepository;
   protected baseURL : string = AppConfiguration.settings.localdbserver.baseURL;
   protected productsPath : string = AppConfiguration.settings.localdbserver.path.products;

   getproducts(): Observable<IProductList[]> {
       return this.restService.httpGet(this.baseURL + this.productsPath);
       //return this._http.get<IProductList[]>(this._producturl)
       //.pipe(catchError(this.errorService.handleError));
             
    //   .map((response: Response) => <IProductList[]> response.json())
    //   //.do(data => console.log(JSON.stringify(data)))
    //   .catch(this.handleError); 
   }

}