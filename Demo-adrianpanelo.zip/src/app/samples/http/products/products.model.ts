export interface IProduct {
    id: number;
    ProductName: string;
 }
 
 export interface IProductList extends IProduct {
    ProductOrdered: boolean;
}