import { Component, OnInit } from '@angular/core';
import { IProductList } from './products.model';
import { ProductService } from './products.service';
// import { appService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
  providers: [ProductService]
})
export class ProductComponent implements OnInit {

  iproducts: IProductList[];
  constructor(private _product: ProductService) {}

  ngOnInit() : void {
      this._product.getproducts()
      .subscribe(iproducts => this.iproducts = iproducts);
     }

     showOrder(product: IProductList) {
      product.ProductOrdered = true;
  }
 
  cancelOrder(product: IProductList) {
   product.ProductOrdered = false;
 }

  
}



