export class githubrepos {
    id: string;
    name: string;
    html_url: string;
    description: string;
}