import { Component, OnInit } from '@angular/core';
import { GitHubService } from './github.service';
import { githubrepos } from './github.model';

@Component({
  selector: 'app-root',
  templateUrl: './httpGetGithubExample.html',
  providers: [GitHubService]
})
export class HttpGetGithubExample implements OnInit {
constructor(private githubService: GitHubService) { }
    ngOnInit(): void {

    }

  
  userName: string = "tektutorialshub";
  repos: githubrepos[];
 
  loading: boolean = false;
  errorMessage; string = "";
 
  
 
  public getRepos(buttonIndex) {
    this.loading = true;
    this.errorMessage = "";
    this.repos = [];
    let params;
    
    if(buttonIndex==2) {
      params =  { sort: "description", page: 2 };
    }
    this.githubService.getRepos(this.userName, params)
      .subscribe(
        (response) => {                           //next() callback
          //console.log('response received')
          this.loading = false;
          this.repos = response; 
        },
        (error) => {                              //error() callback
          //console.error('Request failed with error')
          this.errorMessage = error.toString().replace(/\n/g, "<br />");
          this.loading = false;
        });
  }
}