import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { githubrepos } from './github.model';
import { RESTfulJsonService} from 'src/app/_services/RESTfulJson.service';
import { AppConfiguration } from 'src/app/app-config.service';

@Injectable()
export class GitHubService {
 constructor(private restService: RESTfulJsonService) {}
  
  //baseURL: string = "https://api.github.com/";
  protected repoLink : string = AppConfiguration.settings.links.githubRepository;
  
  getRepos(userName: string, params: any) {
    
    const httpParams = new HttpParams()
    .set('sort', params?.sort)
    .set('page', params?.page);
    //let p = { sort: params.sort, page: params.page };

    let hasParams = params ? true: false;
    let options: any = { showFullError: true, params: hasParams ? httpParams : {} };

    let url: string = this.repoLink.replace("@username",userName);
    console.log("repolink",url);
    return <Observable<githubrepos[]>>this.restService.httpGet(url, options);

      
    //
   // return this.http.get<githubrepos>(this.baseURL.concat('users/',userName ,'/repos'),
     // hasParams ? { 'params': params }: {})
    //  .pipe(catchError(this.errorService.handleError));


    
  }

  
 
}
 