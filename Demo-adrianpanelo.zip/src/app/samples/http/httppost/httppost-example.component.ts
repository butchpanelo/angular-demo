import { Component, OnInit } from '@angular/core';
//import { ApiService } from './api.service';
import { User } from './user.model';
import { Injectable } from '@angular/core';
import { Observable} from 'rxjs';
import { RESTfulJsonService } from 'src/app/_services/RESTfulJson.service';
import { AppConfiguration } from 'src/app/app-config.service';
 
@Component({
  selector: 'app-root',
  templateUrl: './httppost-example.component.html'
})
export class HttpPostExample implements OnInit {
  constructor(private apiService: apiUserService) {}   

  
 people: User[];
 person = new User();

     ngOnInit() {
  
      this.refreshPeople()
  }
 
  refreshPeople() {
    this.apiService.getPeople()
      .subscribe((response) => {
        console.log("getPeople() returned response:", response);
        this.people=response;
      })      
 
  }
 
  addPerson() {
    this.apiService.addPerson(this.person)
      .subscribe((response) => {
        console.log("addPerson() returned response:", response);
        this.refreshPeople();
      })      
  }
 
}

@Injectable({providedIn:'root'})
export class apiUserService {
 
  protected baseURL : string = AppConfiguration.settings.localdbserver.baseURL;
  protected userPath : string = AppConfiguration.settings.localdbserver.path.users;

  constructor(private restService: RESTfulJsonService) {
  }
 
  getPeople(): Observable<User[]> {
    var url = this.baseURL.concat(this.userPath);
    return this.restService.httpGet(url);
  }
 
  addPerson(person:User): Observable<any> {
    var url = this.baseURL.concat(this.userPath);
    //const headers = 
    const body=JSON.stringify(person);
    const options = { "body": body }
     //  "headers": { 'content-type': 'application/json'},
     // "observe" : "body" };

     //   const options = { "body": body };
    return this.restService.httpPost(url, options);
  }
 
}