export class User {
  id:number;
  lastname: string;
  firstname: string;
  password: string;
}