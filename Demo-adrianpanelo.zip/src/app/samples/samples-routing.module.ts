
  import { NgModule }             from '@angular/core';
  import { RouterModule, Routes } from '@angular/router';

  import { ProductComponent } from './http/products/products.component';
import { HttpGetGithubExample } 
  from './http/github/httpGetGithubExample.component';
import { HttpPostExample } 
  from './http/httppost/httppost-example.component';
  import { SamplesComponent } from './samples.component'

 //import { AuthGuard }                from '../auth/auth.guard';
  
//  , redirectTo: './pagenotfound', pathMatch: 'full',
const sampleRoutes: Routes = [
    {
      path: '',
      children: [
        {
          path: '',
      //    canActivateChild: [AuthGuard],
          children: [
            { path: 'http-get-products', component: ProductComponent },
            { path: 'http-get-github', component: HttpGetGithubExample },
            { path: 'http-post-user', component: HttpPostExample }
          ]
        }
      ]

    }
  ];
  
  @NgModule({
    imports: [
      RouterModule.forChild(sampleRoutes)
    ],
    exports: [
      RouterModule
    ]
  })
  export class SamplesRoutingModule {}
  
  export const routedSampleComponents = [
      ProductComponent,
      HttpGetGithubExample,
      HttpPostExample,
      SamplesComponent
  ]
  /*
  Copyright Google LLC. All Rights Reserved.
  Use of this source code is governed by an MIT-style license that
  can be found in the LICENSE file at http://angular.io/license
  */
