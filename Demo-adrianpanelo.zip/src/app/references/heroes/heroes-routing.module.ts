import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HeroListComponent }    from './hero-list/hero-list.component';
import { HeroDetailComponent }  from './hero-detail/hero-detail.component';

import { CanDeactivateGuard} from '../../_services/can-deactivate.guard';

const heroesRoutes: Routes = [
  // { path: 'heroes', redirectTo: '/superheroes' },
  // { path: 'hero/:id', redirectTo: '/superhero/:id' },
  { path: '',  component: HeroListComponent, data: { animation: 'heroes' } ,
  canDeactivate: [CanDeactivateGuard] },
  { path: ':id', component: HeroDetailComponent, data: { animation: 'hero' }, 
  canDeactivate: [CanDeactivateGuard] }
];

@NgModule({
  imports: [
    RouterModule.forChild(heroesRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class HeroesRoutingModule { }
export const routedHeroesComponents = [
  HeroListComponent,
  HeroDetailComponent
]


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/