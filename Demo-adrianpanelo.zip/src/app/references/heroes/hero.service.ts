import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
// import { map, filter } from 'rxjs/operators';
// import { HttpClient } from '@angular/common/http';
import { Hero } from './hero.model';
//import { HEROES } from './mock-heroes';
import { AppConfiguration } from '../../app-config.service';
import { RESTfulJsonService } from '../../_services/RESTfulJson.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class HeroService {
  protected baseURL : string = AppConfiguration.settings.localdbserver.baseURL;
  protected heroesPath : string = AppConfiguration.settings.localdbserver.path.heroes;

  // private _heroes = [];
  constructor(
    //private messageService: MessageService
    private _restService: RESTfulJsonService
    ) {}

  getHeroes(): Observable<Hero[]> {
   let url = `${this.baseURL}${this.heroesPath}`;
    //return of(this._heroes);
   let heroes$ = this._restService.httpGet(url,!environment.production);
   const sub = heroes$.subscribe((data) => this._cacheData = data); 
   return heroes$;
  }

  private _cacheData: Hero[] = [];
  private _cacheHero: Hero;
  get cacheData() {
    return this._cacheData;
  }

  get cacheHero() {
    return this._cacheHero;
  }

  getHero(id: number | string) {
  //  return this.getHeroes().pipe(
      // (+) before `id` turns the string into a number
  //    map((heroes: Hero[]) => heroes.find(hero => hero.id === +id))
  //  );

    let url = `${this.baseURL}${this.heroesPath}/${id}`;
    //.concat(this.heroesPath,"/",id.toString());
    let hero$ = this._restService.httpGet(url,!environment.production);
    const sub = hero$.subscribe((data) => {
        let index = this.cacheData.findIndex(x=> x.id = data.id);
        if(index===-1) {
          this.cacheData.push(data);
        }
        else {
          this.cacheData[index]=data;
        }
        this._cacheHero=data;
    });
    return hero$;
  }

  deleteHero(id: number, callback: any ): void {
    let url = `${this.baseURL}${this.heroesPath}/${id}`;
    // url = `${this.baseURL}${this.heroesPath}/100`;
    this._restService.httpDelete(url,!environment.production).toPromise()
      .then(
      (success)=> {
           callback(true,null);
      })
      .catch((error)=> {  
        console.error(error);
        callback(false,error);   
     });
  }

  updateHero(hero: Hero, callback: any): void {
    let id: number = hero.id;
    let url = `${this.baseURL}${this.heroesPath}/${id}`;
    const options = { "body": JSON.stringify(hero), "showFullError": !environment.production }
    this._restService.httpPut(url,options).toPromise()
      .then(
      (success)=> {
           this._cacheHero = hero;
           callback(true,null);
           //resolve();
      })
      .catch((error)=> {  
        console.error(error);
        callback(false,error);   
     });
  }
}



/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/