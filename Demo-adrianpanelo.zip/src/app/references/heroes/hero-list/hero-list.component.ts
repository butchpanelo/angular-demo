// TODO: Feature Componetized like CrisisCenter
import { Observable, of, Subscription, throwError } from 'rxjs';
import { switchMap, find, toArray, map } from 'rxjs/operators';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { HeroService }  from '../hero.service';
import { Hero } from '../hero.model';
import { HeroChangeInfo } from '../hero-detail/hero-detail.component';
import { MessagingService } from '../../../_services/messaging.service';

@Component({
  selector: 'app-heroes',
  // template: 'hero works',
  templateUrl: './hero-list.component.html',
  styleUrls: ['./hero-list.component.css']
})
export class HeroListComponent implements OnInit {
  loading: boolean=true;
  heroes$: Observable<Hero[]>;
  selectedHero: Hero;
  HeroChanges: changeInfo; 
  subscription: Subscription; 
  constructor(
    private service: HeroService,
    private _route: ActivatedRoute,
    private _messageService: MessagingService
  ) {

    this.HeroChanges =new changeInfo();
  }

  public viewModes: Array<string> = ["Route", "List/Detail", "Parent/Child Detail"];
  public viewModeIndex: number;
  public selectedId: number;
  private get isRouted(): boolean {
    return (this.viewModeIndex===0);
  }
  
  ngOnInit() {
    this.viewModeIndex = 0;
    this.refreshList();
  }

  ngOnDestroy() {
    if(this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  private refreshList() {
    this.loading = true;
    this.heroes$ = this._route.paramMap.pipe(
      switchMap(params => {
        // (+) before `params.get()` turns the string into a number
        if(this.viewModeIndex===0) {
          this.selectedId = +params.get('id');
        }
        return this.service.getHeroes();
      })
    );

    this.subscription = this.heroes$.subscribe(
      () => { this.loading = false;}, 
      (error) => { 
        this.loading = false;
        this._messageService.setMessage(error.toString()).showMessage();
      });  
  }

  canDeactivate(): Observable<boolean> | boolean {
    if(this.isRouted) {
      return true;
    }
    // Allow synchronous navigation (`true`) if no crisis or the crisis is unchanged
    //this.HeroChanges.
    if(this.HeroChanges.hasChanges) {
      return window.confirm('Discard changes?');
    }
    return true;
  }
    // Otherwise ask the user with the dialog service and return its
    // observable which resolves to true or false when the user decides
    

  public getHeroName(hero: Hero) {
    // if(this.isRouted) {
    //   return hero.name;
    // }
    let heroName: string = this.HeroChanges.getHeroName(hero.id);
    return heroName == null ? hero.name : heroName;
  }

  onSelect(id: number) {
    this.selectedId = id;
  }

  deleteHero(hero: Hero) {
    if(window.confirm(`Delete hero ${hero.name}?`)===false) {
      return;
    }
    let _self = this;
    this.service.deleteHero(hero.id, callback);
    
    function callback(success: boolean, error: any) {
      if(success) {
        _self.heroes$ = _self.heroes$.pipe(map( (heroes) => { 
          return heroes.filter((h: { id: number; }) => h.id !== hero.id);
        }));
      }
      else {
        console.log('deleteHero service response: ', error);
      }
      
    }
  }

  toggleView() {
    this.viewModeIndex = this.nextViewMode;
  }

  get nextViewMode(): number {
    let nextIndex = this.viewModeIndex + 1;
    if (this.viewModeIndex + 1 === this.viewModes.length) {
      nextIndex=0;
    }
    return nextIndex;
  }

  onDetailChange(changeInfo: Observable<HeroChangeInfo>) {
    this.HeroChanges.addInfo(changeInfo);
  }

  onDetailCancel(id: number) {
    console.log('onCancel',id);
    this.HeroChanges.remove(id);
   // cmp.hero=null;
    this.selectedId = -1;
  }

  onDetailSave(hero: Hero) {
    console.log('onSave', hero);
    let _self = this;

    this.service.updateHero(hero, callback);

    function callback(success: boolean, error: any) {
      if(success) {
        _self.HeroChanges.remove(hero.id);
        _self.selectedId = -1;
        _self.refreshList();
      }
      else {
        console.log('updateHero service response: ', error);
      }
      
    }
  }
}

class changeInfo {
  private _heroChangeInfo: HeroChangeInfo[];
  
  constructor() {
    this._heroChangeInfo = [];
  }

  get hasChanges(): boolean {
    let self = this;
    let index = this.heroChangeInfo.findIndex((value) => {
      return self.modified(value.hero.id);
    });
    return !(index===-1);
  }
  
  private get heroChangeInfo() {
    return this._heroChangeInfo;
  }

  public getHeroName(id: number): string {
    let index: number = this.getChangeIndex(id);
    if(index === -1 || !this.modified(id)) {
      return null;
    }
    return this.heroChangeInfo[index].hero.name;
  }

  public remove(id: number): boolean {
    let index: number = this.getChangeIndex(id);
    if(index === -1) {
      return false;
    }
    this.heroChangeInfo.splice(index,1);
    return true;
  }

  public addInfo(change: Observable<HeroChangeInfo>): void {
    console.log('from Detail',change);
    let changeInfo: HeroChangeInfo;
    change.subscribe((c) => {  changeInfo = c });
    //let index: number = this.heroChangeInfo.findIndex( x => x.hero.id === changeInfo.hero.id);
    let index: number = this.getChangeIndex(changeInfo.hero.id);
    if(index>-1) {
      this.heroChangeInfo.splice(index,1);
    }
    this.heroChangeInfo.push(changeInfo);
    console.log('modified Heroes',this.heroChangeInfo);
  }

  public modified(id: number): boolean {
    let index: number = this.getChangeIndex(id);
    if(index === -1) {
      return false;
    } 
    let changeInfo = this.heroChangeInfo[index].changeInfo;
    if(changeInfo === null || typeof changeInfo === "undefined") {
      return false;
    }
    let change = changeInfo.find((c) => c.changed===true);
    return (change !=null);
  }

  public modifiedHero(id: number): Observable<Hero> {
    let index: number = this.getChangeIndex(id);
    if(index === -1) {
      return null;
    } 
    return of(this.heroChangeInfo[index].hero);
  }

  public heroData(id:number): Observable<any> {
    let index: number = this.getChangeIndex(id);
    if(index === -1) {
      return null;
    }
    let changeInfo = this.heroChangeInfo[index];
    return of({ modified: changeInfo.hero, 
      original: changeInfo.originalHero });
  }

  private getChangeIndex(id: number): number 
  {
    if(this.heroChangeInfo===null || typeof this.heroChangeInfo==="undefined") {
      return -1;
    }
    let index: number = this.heroChangeInfo.findIndex(x => x.hero.id===id);
    return index;
  }

}

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/