import { switchMap, toArray, delay } from 'rxjs/operators';
import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { Observable, of, Subscription } from 'rxjs';

import { HeroService }  from '../hero.service'
import { Hero } from '../hero.model';

@Component({
  selector: 'app-hero-detail',
  templateUrl: './hero-detail.component.html',
  styleUrls: ['./hero-detail.component.css']
})
export class HeroDetailComponent implements OnInit {
  loading : boolean = true;
  //--> Routed view
  hero$: Observable<Hero>;
  //<--

  //--> Child Component view
  hero: Hero;
  originalHero: Hero;

  // public _routed: boolean;
  @Input() routed: boolean
    // set routed(value: boolean)  {
    //   this._routed=value;
    // }
    // get routed(): boolean {
    //   return this._routed;
    // }
  // private _id: number;
  @Input('hero-id') id: number;
    // set id(value: number) {
    //   this._id = value;
    // }
    // get id(): number {
    //   return this._id;
    // }
  @Input('hero-data') heroData: Observable<any>
    
  @Output() onInputChange = new EventEmitter<Observable<HeroChangeInfo>>();
  @Output() onCancel = new EventEmitter<number>();
  @Output() onSave = new EventEmitter<Hero>();
  //<--

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: HeroService
  ) {}
  private subscription: Subscription;
  public isRouteMode: boolean;


  @ViewChild("idInput") idInput: ElementRef;
  @ViewChild("nameInput") nameInput: ElementRef;
  @ViewChild("descriptionInput") descriptionInput: ElementRef;

  canDeactivate(): Observable<boolean> | boolean {
    if(!this.isRouteMode) { 
      return true;
    }
    let isModified = this.isModified();
    if(isModified) {
      return window.confirm('Discard changes?');
    }
    return true;
  }

  private isModified(): boolean {
    console.log("id",this.idInput);
    console.log("name",this.nameInput);
    console.log("description",this.descriptionInput);
    let cached : Hero = this.service.cacheHero
    let elName = this.nameInput.nativeElement;
    let elDescription = this.descriptionInput.nativeElement;
    if(elName.classList.contains("ng-dirty") && elName.value !== cached.name) {
      return true;
    }
    else if(elDescription.classList.contains("ng-dirty") && elDescription.value !== cached.description) {
      return true;
    }
    return false;
  }
  
  ngOnInit() {
    this.loading = true;
    this.isRouteMode = (typeof this.routed === "undefined");
    //--> Routed view
    if(this.isRouteMode) {
      this.hero$ = this.route.paramMap.pipe(
        switchMap((params: ParamMap) =>
          this.service.getHero(params.get('id')))
      );

      this.subscription = this.hero$.subscribe(
        () => { this.loading = false;}, 
        (error) => { this.loading = false;});      
    }
    //<--
    //--> Child Component view
    else {
      this.refreshData();
      
    }
    //<--
  }

  //--> Child Component view
  private inputState: any;
  private refreshData() {
    if(this.id<=0) return;
    this.loading = true;
    let self = this;

    if(this.heroData !==null && typeof this.heroData !== 'undefined') {
      let heroData : any;
      this.subscription = this.heroData.subscribe(
        (data) =>{ heroData = data; },
        () => { this.loading = false;},
        () => { this.loading = false;}
         
      );
      this.hero = heroData.modified;
      this.originalHero = heroData.original;
      initInputState(this.originalHero);
      return;
    }
    
    this.subscription = this.service.getHero(this.id).subscribe(
      (data) => {    
        console.log('data',data)   ;                 //next() callback
        this.originalHero = Object.assign({}, data); // shallow copy, data properties are primitive types
        this.hero = data;
        initInputState(this.originalHero);
      },
      (error) => {                              //error() callback
        //console.error('Request failed with error')
       //
        this.loading = false;
      },
      () => {
        console.log('getHero Request completed.');
        this.loading = false;
      }
    );

    function initInputState(data: Hero) {
        self.inputState = {};
        Object.entries(data).forEach((key)=> {
          self.inputState[key[0]] = { 'changed': false };
        });
        console.log('inputState', self.inputState);
    }
  }

  ngOnDestroy() {
    if(this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  getEmitObject(newValue: string): Observable<HeroChangeInfo> {
    let vm = this;
    let changeInfo = Object.keys(this.inputState).map((value,index,keys)=> {
       let propInfo = new HeroChangePropertyInfo;
       propInfo.propertyName = keys[index];
       propInfo.changed = vm.inputState[keys[index]].changed;
       return propInfo;
    });
    //.filter(x => x.changed);
      let returnObject = new HeroChangeInfo;
      returnObject.hero = vm.hero;
      returnObject.originalHero = vm.originalHero;
      returnObject.changeInfo = changeInfo;
    console.log('getEmitObject',returnObject);
    return of(returnObject);
  }

  emitChange(eventTarget: any, propertyName: string) {
      this.inputState[propertyName].changed=(eventTarget.value !== this.originalHero[propertyName]);
      this.onInputChange.emit(this.getEmitObject(eventTarget.value));
  }

  emitCancel() {
      this.onCancel.emit(this.id);
  }

  emitSave() {
    this.onSave.emit(this.hero);
  }

  
  //<-- 

  ngOnChanges(changes: SimpleChanges): void {
    if(changes.routed) return;
    if(changes.id) {
      if(changes.id.firstChange) return;
      this.refreshData();
    }
  }

  //--> Routed view
  saveClick(hero: Hero) {
    console.log('saveClick', hero);
    let _self = this;

    this.service.updateHero(hero, callback);

    function callback(success: boolean, error: any) {
      if(success) {
        _self.gotoHeroes(hero);
      }
      else {
        console.log('updateHero service response: ', error);
      }
      
    }
    
  }

  // cancel click
  gotoHeroes(hero: Hero) {
    let heroId = hero ? hero.id : null;
    // Pass along the hero id if available
    // so that the HeroList component can select that hero.
    // Include a junk 'foo' property for fun.
    //this.router.navigate(['/superheroes', { id: heroId, foo: 'foo' }]);
    this.router.navigate(['/superheroes', { id: heroId }]);
  }
  //<--
}

export class HeroChangeInfo {
  hero: Hero; 
  originalHero: Hero;
  changeInfo: HeroChangePropertyInfo[];
}

export class HeroChangePropertyInfo {
  propertyName: string;
  changed: boolean
}


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/