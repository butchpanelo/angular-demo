import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { SidebarModule } from 'ng-sidebar';
//import { ResizedEvent } from 'angular-resize-event';

//@Components
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { MessageSidebarComponent } from './sidebar/message/message-sidebar.component';
import { ShowMessageComponent } from './show-message/show-message.component';

//Routing
import { AppRoutingModule, routedComponents } from './app-routing.module';

//Guard
import { AuthGuard } from './auth/auth.guard';

//Initializer
import { AppConfiguration } from './app-config.service';

//Shared Modules
import { UserModule }              from './user/user.module';

//Diagnostic
// import { Router } from '@angular/router';
 
export function loadConfig(config: AppConfiguration) {
    return (): Promise<any> => { 
      return config.load();
    }
  }

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    MessageSidebarComponent,
    routedComponents,
    ShowMessageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    HttpClientModule,
    FormsModule, ReactiveFormsModule,
    BrowserAnimationsModule,
    SidebarModule.forRoot(),
    UserModule
  ],
  providers: [HttpClientModule,
    AppConfiguration,
    { provide: APP_INITIALIZER, useFactory: loadConfig, deps: [AppConfiguration], multi: true},
    AuthGuard
  ],
  bootstrap: [AppComponent, NavbarComponent]
})
export class AppModule { 
// Diagnostic only: inspect router configuration
// constructor(router: Router) {
  // Use a custom replacer to display function names in the route configs
  // const replacer = (key, value) => (typeof value === 'function') ? value.name : value;

  // console.log('Routes: ', JSON.stringify(router.config, replacer, 2));
// }
}
