import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { AppConfiguration } from '../../app-config.service';
import { MessagingService} from '../../_services/messaging.service';
import { AuthService } from '../../auth/auth.service';
import { UserService } from '../../user/_services/user.service';

import { Utility } from '../../_global/utility';

import { LOGIN_LINKS } from '../login-landing/login-landing';
import { compareValidator, spaceBeforeTextValidator  } from '../../_validators';
import { emailAvailableValidator, usernameAvailableValidator } from '../../_validators';
import { FORM_STATUS, fn_toggleShowPassword, fn_topRightPopoverShown } 
   from '../../_global/forms'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html', 
  styleUrls: ['../_css/common.css','../../_css/forms.css','./register.component.css']
  // changeDetection: ChangeDetectionStrategy.OnPush
})
export class RegisterComponent implements OnInit {
  protected homeUrl = AppConfiguration.settings.routes.home;
  loading: boolean;
  form: FormGroup;
  subscription: Subscription;
  constructor(private _msgService: MessagingService,
    private _authService: AuthService,
    private _router: Router,
    private _fb: FormBuilder,
    private _userService: UserService) { 

      this.initForm();
      
      

  }
   
  protected labelNames = [
          { key: "email", text:"Email Address" },
          { key:"username", text:"Preferred Username"},
          { key:"password", text:"Password"},
          { key:"confirmPassword", text:"Verify Password"} ];
  
  @Input('sidebar') sidebar: boolean;
  @Output() onLinkClick = new EventEmitter<LOGIN_LINKS>();
  @Output() formStatus = new EventEmitter<FORM_STATUS>();
  
  private initForm(): void {    
    this.form = this._fb.group( {
      email: ['', Validators.pattern(AppConfiguration.settings.pattern.email.regexpr),
        emailAvailableValidator.createValidator(this._userService)
        ],
      username: ['', spaceBeforeTextValidator(), 
        usernameAvailableValidator.createValidator(this._userService)
      ],
      password: ['', Validators.pattern(AppConfiguration.settings.pattern.password.regexpr)],
      confirmPassword: ['', [
        Validators.pattern(AppConfiguration.settings.pattern.password.regexpr),
        compareValidator('password',false)]]
    });

    this.subscription = this.form.controls.password.valueChanges.subscribe(() => {
      this.form.controls.confirmPassword.updateValueAndValidity();
    });

    //this.form.controls.confirmPassword.e
  }

  get passwordCriteria(): string {
    return AppConfiguration.settings.pattern.password.criteria;
  }

  getLabelName(controlName: string): string {
    return this.labelNames[this.labelNames.findIndex((x) => { return x.key===controlName})].text;
  }

  getPopoverTitle(controlName: string): string {
    return `Invalid '${this.getLabelName(controlName)}'`;
  }

  getValidationMessage(controlName: string) : string{
    let control = this.form.get(controlName);
    let message: string;
    if(control.errors?.required) {
      return "The field is required.";
    }
    switch(controlName) {
      case "email":
        if(control.errors?.pattern) {
          message = `The email address - ${control.value} - is not in correct format.`;
        }
        else if(control.errors?.available) {
          message = `The email address - ${control.value} - is already taken.`;
        }
        break;
      case "username":
        if(control.errors?.spaceBeforeText) {
          message = "Space(s) before the text is not allowed."
        }
      case "password":
        if(control.errors?.pattern) {
          message = "Password does not meet the minimum requirement."
        }
        break;
      case "confirmPassword":
        if(control.errors?.compare) {
          message = "Password and Verify Password do not match."
        }
        else if(control.errors?.pattern) {
          message = "Password does not meet the minimum criteria."
        }
        break;
    }
    return message || "Unknown error";  
  }

  get formValue(): string {
    return JSON.stringify(this.form.value);
  }

  // popoverShown(el: HTMLElement) {
  //   let popoverId: string = el.getAttribute("aria-describedby");
  //   let placement: string = el.getAttribute("placement");
  //   if(placement==="top-right") {
  //     let popoverEl: HTMLElement = document.getElementById(popoverId);
  //     let arrowEl: HTMLElement = popoverEl.querySelector(".arrow");
  //     //let arrowElRect = arrowEl.getBoundingClientRect();
  //     //let elRect = el.getBoundingClientRect();
  //     //let popoverRect = popoverEl.getBoundingClientRect();
  //     //arrowEl.style.left = `${popoverRect.width - arrowEl.clientWidth}px`;
  //     arrowEl.style.left = `${popoverEl.clientWidth - arrowEl.clientWidth}px`;
  //   }
  // }
  
  popoverShown = fn_topRightPopoverShown;
  toggleShowPassword = fn_toggleShowPassword;

  isEmpty(value: string): boolean {
    return Utility.isEmptyOrNullString(value);
  }

  ngOnInit(): void {
    this.sidebar = this.sidebar || false;
    
  }

  ngOnDestroy(): void {
    if(this.subscription) {
      this.subscription.unsubscribe();
    }
  }
  
  onInputChange($event: { target: any; }) {
    let el = $event.target;
    el.value==="" ? el.classList.remove("filled") :  el.classList.add("filled");
  }
  
  onSubmit() {
    let _self = this;
   
  }

  cancelClick() {
    this.initForm();
    if(this.sidebar) {
      this.formStatus.emit("cancel");
    }
    else {
      this._router.navigate([this.homeUrl]);
    }
  }
}

// export function fnToggleShowPassword($event: { target: any; }, inputRef: HTMLElement) {
//     let el = $event.target;
//     if(el.classList.contains("fa-eye")) {
//       el.classList.remove("fa-eye");
//       el.classList.add("fa-eye-slash");
//       inputRef.setAttribute("type","text");
//     } 
//     else {
//       el.classList.remove("fa-eye-slash");
//       el.classList.add("fa-eye");
//       inputRef.setAttribute("type","password");
//     }
//   }

