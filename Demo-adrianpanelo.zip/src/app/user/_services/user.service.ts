import { Injectable } from '@angular/core';
import { Observable, of, pipe } from 'rxjs';
import { delay, map } from 'rxjs/operators';

@Injectable({providedIn: 'root'})
export class UserService {

    private allEmail = ["abc@g.com", "adriancpanelo@gmail.com" ];
    private allUsername = ["adrian", "butch"];

    isEmailExists(email: string): Observable<boolean> {
        return of(this.allEmail.includes(email)).pipe(delay(5000));
    }

    isUsernameExists(username: string): Observable<boolean> {
        return of(this.allUsername.includes(username)).pipe(delay(5000));
    }
}

