import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AppConfiguration } from '../../app-config.service';

import { MessagingService} from '../../_services/messaging.service';
import { AuthService } from '../../auth/auth.service';
import { ActionService } from '../../_services/action.service';
import { LocalStorageService} from '../../_services/localstorage.service'

import { LOGIN_LINKS } from '../login-landing/login-landing';
import { FORM_STATUS, fn_topRightPopoverShown, fn_toggleShowPassword } from 'src/app/_global/forms';
import { emptyTextValidator } from '../../_validators'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html', 
  styleUrls: ['../_css/common.css','../../_css/forms.css']
})
export class LoginComponent implements OnInit {
  protected homeUrl = AppConfiguration.settings.routes.home;
  protected loginStorage: loginStorage;
  loading: boolean;
  form: FormGroup;
   /* this._fb.group( {
    username: [''],
    password: [''],
    remember: false
  });
 */
  constructor(private _msgService: MessagingService,
    private _authService: AuthService,
    private _router: Router,
    private _actionService: ActionService,
    private _localstorage: LocalStorageService,
    private _fb: FormBuilder) { 

      this.loginStorage = new loginStorage(this._localstorage);
      this.initForm();
      
  }

  protected labelNames = [
    { key: "usernameOremail", text:"Username or Email" },
    { key:"password", text:"Password"} ]
  
  @Input('sidebar') sidebar: boolean;
  @Output() onLinkClick = new EventEmitter<LOGIN_LINKS>();
  @Output() formStatus = new EventEmitter<FORM_STATUS>();
  
  private initForm(): void {
    // this.form = new FormGroup({
    //   username: new FormControl(''),
    //   password: new FormControl(''),
    //   remember: new FormControl(false)
    // }); 
//, Validators.pattern("^\\w+$")
    // , Validators.pattern(`^(?!\\s*$).+`)
    this.form = this._fb.group( {
      usernameOremail: ['', emptyTextValidator() ],
      password: ['', Validators.required],
      remember: false
    });

    let stored: any = this.loginStorage.get();
    console.log('loginStorage',stored);
    if(stored!==null) {
      
      this.form.controls.usernameOremail.setValue(stored.username);
      this.form.controls.password.setValue(stored.password);
      this.form.controls.remember.setValue(true);
    }
  }

  getLabelName(controlName: string): string {
    return this.labelNames[this.labelNames.findIndex((x) => { return x.key===controlName})].text;
  }

  getPopoverTitle(controlName: string): string {
    return `Invalid '${this.getLabelName(controlName)}'`;
  }

  getValidationMessage(controlName: string) : string{
    let control = this.form.get(controlName);
    let message: string;
    if(control.errors?.required) {
      return "The field is required.";
    }
    switch(controlName) {
      case "usernameOremail":
        if(control.errors?.empty) {
          message = "The field is required.";
        }
        break;
      case "password":
        break;
    }
    return message || "Unknown error";  
  }

  popoverShown = fn_topRightPopoverShown;
  toggleShowPassword = fn_toggleShowPassword;

  get formValue(): string {
    return JSON.stringify(this.form.value);
  }

  
  
  ngOnInit(): void {
    this.sidebar = this.sidebar || false;
    
  }

  onInputChange($event: { target: any; }) {
    let el = $event.target;
    el.value==="" ? el.classList.remove("filled") :  el.classList.add("filled");
  }

  onSubmit() {
    let _self = this;
    let isAuthenticated: boolean;
    if(!this.form.controls.remember.value) {
      this.loginStorage.remove();
    }
   // console.log(f);
    this._authService.authenticate("Butch","1234").subscribe(() => {
    
      console.log('credentials',this._authService.credentials);
      
      if (this._authService.credentials) {

        this._msgService.setMessage("Login successful.")
        .setMessageHeader("Login")
        .setDuration(10000)
        .setMessageType("success")
        .showMessage();

        if(this.form.controls.remember.value) {
          this.loginStorage.add(this.form.controls);
        }
        // Usually you would use the redirect URL from the auth service.
        // However to keep the example simple, we will always redirect to `/admin`.
        //const redirectUrl = '/admin';
        const redirectUrl = this._authService.redirectUrl;
        if(redirectUrl && redirectUrl.length>0) {
          // Set our navigation extras object
          // that passes on our global query params and fragment
          let navigationExtras: NavigationExtras = {
            queryParamsHandling: 'preserve',
            preserveFragment: true
          };

        // Redirect the user
          this._router.navigate([redirectUrl], navigationExtras);
        }
        else {
          this._router.navigate([this.homeUrl]);
        }
        isAuthenticated=true;
      }
      else {
        isAuthenticated=false;
        this._msgService.setMessage("Login failed.")
          .setMessageHeader("Login")
          .setDuration(10000)
          .setMessageType("error")
          .showMessage();
      }
      // if(isAuthenticated) {
      //   this._actionService.push("LOGGED-IN");
      // }
      this.formStatus.emit(isAuthenticated?"success":"error");
      this.initForm();
    }, 
    (error) => {
      this.formStatus.emit("error");
      this.initForm();
    })
  }

  cancelClick() {
    this.initForm();
    if(this.sidebar) {
      this.formStatus.emit("cancel");
    }
    else {
      this._router.navigate([this.homeUrl]);
    }
  }
}

class loginStorage {
  protected storekey: string = "login-remember";
  constructor(private _localstorage: LocalStorageService) {}
  public add(controls: any) {
    this._localstorage.store(this.storekey, {
    "username": `${controls.usernameOremail.value}`,
    "password": `${controls.password.value}`
  });
  }
  
  public get(): object {
    let loginInfo: any = this._localstorage.getItem(this.storekey);
    if(loginInfo===null) {
      return null;
    }
    return JSON.parse(loginInfo);
  }

  public remove() {
    this._localstorage.remove(this.storekey);
  }

}
