import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { Router} from '@angular/router';

import { AppConfiguration } from '../../app-config.service';
import { FORM_STATUS } from '../../_global/forms/form-status.type';
import { LOGIN_LINKS } from './login-landing';

@Component({
  selector: 'app-login-landing',
  templateUrl: './login-landing.component.html', 
  styleUrls: ['./login-landing.component.css']
})
export class LoginLandingComponent implements OnInit {
  protected homeUrl = AppConfiguration.settings.routes.home;
  @Input() sidebar : boolean;
  @Output() formStatus  = new EventEmitter<FORM_STATUS>();
  viewMode: LOGIN_LINKS
  constructor(private _router: Router) {
      this.sidebar = false;
      this.viewMode="login";
  }

  ngOnInit(): void {
    
  }

  onLinkClick(viewMode: LOGIN_LINKS) {
    this.viewMode=viewMode;
    switch(viewMode) {
      case "privacy": case "terms-of-service":
        this.emitFormStatus("cancel");
        this._router.navigate([`${this.homeUrl}{viewMode}`]);
        break;
      default:
        break;
    }
  }

  emitFormStatus(status: FORM_STATUS) {
    this.formStatus.emit(status);
  }
 
}
