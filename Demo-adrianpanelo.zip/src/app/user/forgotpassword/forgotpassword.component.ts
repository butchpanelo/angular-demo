import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators, Validator, MaxLengthValidator } from '@angular/forms';
import { Router } from '@angular/router';

import { AppConfiguration } from '../../app-config.service';
import { MessagingService } from '../../_services/messaging.service';
import { ActionService } from '../../_services/action.service';
import { AuthService } from '../../auth/auth.service';

import { LOGIN_LINKS } from '../login-landing/login-landing';
import { FORM_STATUS, fn_topRightPopoverShown } from 'src/app/_global/forms';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgotpassword.component.html', 
  styleUrls: ['../_css/common.css','../../_css/forms.css']
})
export class ForgotPasswordComponent implements OnInit {
  protected homeUrl = AppConfiguration.settings.routes.home;
  loading: boolean;
  form: FormGroup;
  constructor(private _msgService: MessagingService,
    private _router: Router,
    private _actionService: ActionService,
    private _fb: FormBuilder) { 
      this.initForm();
  }

  protected labelNames = [
    { key: "email", text: "Email Address" } ];
  
  @Input('sidebar') sidebar: boolean;
  @Output() onLinkClick = new EventEmitter<LOGIN_LINKS>();
  @Output() formStatus = new EventEmitter<FORM_STATUS>();
  //^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$
  private initForm(): void {
    this.form = this._fb.group( {
      email: ['', Validators.pattern("^"+AppConfiguration.settings.pattern.email.regexpr)]
    });
  }

  getLabelName(controlName: string): string {
    return this.labelNames[this.labelNames.findIndex((x) => { return x.key===controlName})].text;
  }

  getPopoverTitle(controlName: string): string {
    return `Invalid '${this.getLabelName(controlName)}'`;
  }

  getValidationMessage(controlName: string) : string{
    let control = this.form.get(controlName);
    let message: string;
    if(control.errors?.required) {
      return "The field is required.";
    }
    switch(controlName) {
      case "email":
        if(control.errors?.pattern) {
          message = `The email address - ${control.value} - is not in correct format.`;
        }
        break;
    }
    return message || "Unknown error";  
  }

  popoverShown = fn_topRightPopoverShown;
  
  get formValue(): string {
    return JSON.stringify(this.form.value);
  }

  ngOnInit(): void {
    this.sidebar = this.sidebar || false;
  }

  onInputChange($event: { target: any; }) {
    let el = $event.target;
    el.value==="" ? el.classList.remove("filled") :  el.classList.add("filled");
  }

  onSubmit() {
    this.initForm();
  }

  cancelClick() {
    this.initForm();
    if(this.sidebar) {
      this.formStatus.emit("cancel");
    }
    else {
      this._router.navigate([this.homeUrl]);
    }
  }
}