import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginLandingComponent } from './login-landing/login-landing.component';
import { LogoutComponent } from './logout/logout.component';
import { AuthGuard } from '../auth/auth.guard';

const userRoutes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'logout', component: LogoutComponent },
  { path: 'login', component: LoginLandingComponent, canActivate: [AuthGuard]
}
];

@NgModule({
  imports: [
    RouterModule.forChild(userRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class UserRoutingModule {}


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/
