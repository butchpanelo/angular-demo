import { NgModule }       from '@angular/core';
import { CommonModule }   from '@angular/common';
import { FormsModule, ReactiveFormsModule }    from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LoginLandingComponent }    from './login-landing/login-landing.component';
import { LogoutComponent }    from './logout/logout.component';

import { LoginComponent }    from './login/login.component';
import { ForgotPasswordComponent }    from './forgotpassword/forgotpassword.component';
import { RegisterComponent }    from './register/register.component';

import { UserRoutingModule } from './user-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule, 
    ReactiveFormsModule,
    UserRoutingModule,
    NgbModule
  ],
  declarations: [
    LoginComponent,
    LoginLandingComponent,
    ForgotPasswordComponent,
    RegisterComponent,
    LogoutComponent
  ],
  exports: [
    CommonModule, FormsModule, ReactiveFormsModule, NgbModule,
    LoginLandingComponent,
    LoginComponent,  
    ForgotPasswordComponent,
    RegisterComponent,
    LogoutComponent
  ]
})
export class UserModule {}


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/