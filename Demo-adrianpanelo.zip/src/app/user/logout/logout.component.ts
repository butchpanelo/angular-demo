import { Component, OnInit } from '@angular/core';
import { Router }  from '@angular/router';
// import { NgbDropdown } from '@ng-bootstrap/ng-bootstrap';
import { AppConfiguration } from '../../app-config.service';
import { AuthService } from '../../auth/auth.service';
import { MessagingService } from '../../_services/messaging.service';
import { ActionService } from '../../_services/action.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
  protected homeUrl = AppConfiguration.settings.routes.home;

  constructor(private _router: Router, 
    private _authService: AuthService,
    private _msgService: MessagingService) { }

  ngOnInit(): void {
    this._authService.logout();
    this._msgService.closeMessage();
    this._router.navigate([this.homeUrl]);
  }

}
