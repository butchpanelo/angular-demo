import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './angular-start.component.html',
  styleUrls: ['./angular-start.component.css']
})
export class AngularStartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  title = "Demo Application";
  

}
