import { Component, OnInit, HostListener, OnDestroy } from '@angular/core';
import { fadeInAnimation, slideInOutAnimation } from '../_animations/index';


@Component({
  selector: 'app-root',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
 // animations: [fadeInAnimation],
  //host: { '[@fadeInAnimation]': '',
 

    
})
export class HomeComponent implements OnInit, OnDestroy {

  constructor() { }

  ngOnInit(): void {
  }

  //name = 'World'; 
  //constructor(@Environment(‘test’ private appTitle:string) { }
  //@Environment(‘test’);
  
  appTitle: string = 'Welcome';
  hidden: boolean = false;
  
  appStatus: boolean = true;

  appList: any[] = [ {
    "ID": "1",
    "Name" : "One",
    "style" : 'red', 
    "style2" : {
      'color': 'red',
      'font-size': '14px',
      'text-transform' : 'uppercase'
    }
 },

 {
    "ID": "2",
    "Name" : "Two",
    "style": 'blue',
    "style2" : {
      'color': 'blue',
      'font-size': '16px',
      'text-transform' : 'lowercase'
    }
 } ];

 textinput: string = "";

 toggleContent() {
    this.hidden = !this.hidden;
 }

 

  ontextinput(text: string) {
   console.log(text);
 }

 @HostListener('undloaded')
 ngOnDestroy(): void {
   console.log('Home Component destroyed');
 }

}
