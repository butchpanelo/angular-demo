export class Utility {
    static isAllWhiteSpace(value: any) {
        if(Utility.isEmptyOrNullString(value)) {
            return true;
        }
        // all whitespaces
        if(/^[\s]*$/.test(value)) {
            return true;
        }
        return false;
    }

    static isEmptyOrNullString(value: any) {
        if(typeof value !=='string') {
            return false;
        }
        if(typeof value===undefined) {
            throw new Error("isEmptyString(value): value is undefined");
        }
        // null
        if(value===null) {
            return true;
        }
        // all spaces
        if(value.trim()==="") {
            return true;
        }
        return false;
    }
}
