export function fn_topRightPopoverShown(el: HTMLElement) {
    let popoverId: string = el.getAttribute("aria-describedby");
    let placement: string = el.getAttribute("placement");
    if(placement==="top-right") {
      let popoverEl: HTMLElement = document.getElementById(popoverId);
      let arrowEl: HTMLElement = popoverEl.querySelector(".arrow");
      //let arrowElRect = arrowEl.getBoundingClientRect();
      //let elRect = el.getBoundingClientRect();
      //let popoverRect = popoverEl.getBoundingClientRect();
      //arrowEl.style.left = `${popoverRect.width - arrowEl.clientWidth}px`;
      arrowEl.style.left = `${popoverEl.clientWidth - arrowEl.clientWidth}px`;
    }
  }