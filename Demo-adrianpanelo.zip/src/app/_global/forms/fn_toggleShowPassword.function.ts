export function fn_toggleShowPassword($event: { target: any; }, inputRef: HTMLElement) {
    let el = $event.target;
    if(el.classList.contains("fa-eye")) {
      el.classList.remove("fa-eye");
      el.classList.add("fa-eye-slash");
      inputRef.setAttribute("type","text");
    } 
    else {
      el.classList.remove("fa-eye-slash");
      el.classList.add("fa-eye");
      inputRef.setAttribute("type","password");
    }
  }